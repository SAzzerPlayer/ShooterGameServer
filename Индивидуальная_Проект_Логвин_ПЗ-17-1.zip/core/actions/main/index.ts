export {bindUser as mainBindUser} from './bindUser';
export {checkUser as mainCheckUser} from './checkUser';
export {pong as mainPong} from './pong';
