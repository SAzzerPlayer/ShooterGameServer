import {GameServer} from '../../index';
import {TWSMessage} from '../../shared';

export const startStage = (roomId: string) => {
  const room = GameServer.getRoomsCollection().getRoomBy(roomId);
  if (room && room.users) {
    room.start();
    const message = {
      type: 'GAME/UPDATE' as TWSMessage,
      data: {
        room: {
          game: {
            enemies: room.core?.enemies.map((enemy) => ({
              position: enemy.position,
              width: 16,
              height: 16,
            })),
          },
        },
        result: true,
      },
    };
    GameServer.sendToUsers(
      room.users.map((currentUser) => currentUser.username),
      message,
    );
  }
};
