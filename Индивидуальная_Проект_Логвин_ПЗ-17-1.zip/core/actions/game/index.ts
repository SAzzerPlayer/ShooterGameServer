export {startStage as gameStartStage} from './startStage';
