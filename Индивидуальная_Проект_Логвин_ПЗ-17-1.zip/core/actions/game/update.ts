import {GameServer} from '../../index';

export const update = (roomId: string) => {
  const room = GameServer.getRoomsCollection().getRoomBy(roomId);
  if(room && room.users) {
    const message = {
      type: 'GAME/UPDATE',
      data: {
        room: {
          single: {
            id: roomId,
          },
        }
      }
    }
  }
};
