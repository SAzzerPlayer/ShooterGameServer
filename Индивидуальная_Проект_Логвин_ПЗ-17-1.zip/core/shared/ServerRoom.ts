import {ServerUser} from './ServerUser';
import {GameCollection} from '../components/GameCollection';

export enum EServerRoomComplexity {
  Easy = 'Easy',
  Medium = 'Medium',
  Hard = 'Hard',
  Impossible = 'Impossible',
}

export type TServerRoomUserLimit = 1 | 2 | 3 | 4;

export interface IServerRoomParams {
  id?: string;
  complexity?: EServerRoomComplexity;
  usersLimit?: TServerRoomUserLimit;
  usersAmount?: number;
}

export class ServerRoom {
  id: string;
  complexity: EServerRoomComplexity;
  usersLimit: TServerRoomUserLimit;
  users: ServerUser[];
  core?: GameCollection;

  constructor(
    id: string | IServerRoomParams,
    complexity: EServerRoomComplexity = EServerRoomComplexity.Easy,
    usersLimit: TServerRoomUserLimit = 1,
  ) {
    if (typeof id === 'string') {
      this.id = id as string;
      this.complexity = complexity;
      this.usersLimit = usersLimit;
    } else {
      const params = id as IServerRoomParams;
      this.id = params.id!;
      this.complexity = params.complexity!;
      this.usersLimit = params.usersLimit!;
    }
    this.users = [];
    this.core = undefined;
  }

  joinUser = (user: ServerUser) => {
    const {users, usersLimit} = this;
    if (users.length < usersLimit && user) {
      users.push(user);
      return true;
    }
    return false;
  };

  start = () => {
    const field = {
      xStart: 100,
      xEnd: 500,
      yStart: 100,
      yEnd: 300,
    };
    this.core = new GameCollection(this.complexity, field, this.users);
    this.core.start();
  };
}
