import {EServerRoomComplexity, ServerUser} from '../shared';

function getRandomInt(max: number) {
  return Math.floor(Math.random() * Math.floor(max));
}

function getDistance(dot1: IPoint, dot2: IPoint) {
  return Math.sqrt(Math.pow(dot2.x - dot1.x, 2) + Math.pow(dot2.y - dot1.y, 2));
}

export enum EGameCollectionStatus {
  WAITING = 'WAITING',
  STAGE = 'STAGE',
  END = 'END',
}

export class ServerUserGamer {
  maxHealth: number;
  health: number;
  energy: number;
  power: number;
  username: string;
  constructor(health: number, power: number, username: string) {
    this.maxHealth = health;
    this.health = health;
    this.energy = 100;
    this.power = power;
    this.username = username;
  }
  setHealth = (health: number) => {
    this.health = health;
  };
  getDamage = (damage: number) => {
    if (this.health - damage <= 0) {
      this.health = 0;
    } else {
      this.health -= damage;
    }
  };

  getPower = () => this.power;
  shot = () => {
    this.energy -= 10;
  };
  updateEnergy = () => {
    if (this.energy < 100) {
      this.energy += 10;
    }
  };
  updateHealth = () => {
    if (this.health + 5 < this.maxHealth) {
      this.health += 5;
    }
  };
}

export interface IEnemyBody {
  position: IPoint;
  radius: number;
}

export interface IPoint {
  x: number;
  y: number;
}

export interface IField {
  xStart: number;
  xEnd: number;
  yStart: number;
  yEnd: number;
}

export class ServerEnemy {
  width: number;
  height: number;
  health: number;
  power: number;
  reward: number;
  body: IEnemyBody[];
  position: IPoint;
  constructor(health: number, power: number, body: IEnemyBody[], reward: number) {
    this.health = health;
    this.power = power;
    this.body = body;
    this.position = {x: 50, y: 50};
    this.width = 0;
    this.height = 0;
    this.reward = reward;
  }
  setHealth = (health: number) => {
    this.health = health;
  };
  getHealth = () => this.health;
  getDamage = (power: number) => {
    if (this.health - power > 0) {
      this.health -= power;
    } else {
      this.health = 0;
    }
  };
  setPosition = (position: IPoint) => {
    this.position = position;
  };
  autoMove = (gameField: IField) => {
    const {xStart, xEnd, yStart, yEnd} = gameField;
    const [moveX, moveY] = [getRandomInt(8) - 4, getRandomInt(8) - 4];
    const {position} = this;
    if (position.x + moveX >= xEnd) {
      position.x -= moveX;
    } else if (position.x - moveX <= xStart) {
      position.x += moveX;
    } else {
      position.x += moveX;
    }
    if (position.y + moveY >= yEnd) {
      position.y -= moveY;
    } else if (position.y - moveY <= yStart) {
      position.y += moveY;
    } else {
      position.y += moveY;
    }
  };
  shot = (dot: IPoint, damage: number): boolean => {
    for (const body of this.body) {
      const bodyPosition = {
        x: body.position.x + this.position.x,
        y: body.position.y + this.position.y,
      };
      const distance = getDistance(dot, bodyPosition);
      if (distance < body.radius) {
        this.getDamage((distance / body.radius) * damage);
        return true;
      }
    }
    return false;
  };
  clone = () => {
    return new ServerEnemy(this.health, this.power, this.body, this.reward);
  };
}

const Enemies = {
  Light: new ServerEnemy(15, 2, [{position: {x: 5, y: 5}, radius: 2}], 20),
  Medium: new ServerEnemy(25, 4, [{position: {x: 5, y: 5}, radius: 2}], 50),
  Large: new ServerEnemy(40, 5, [{position: {x: 5, y: 5}, radius: 2}], 100),
};

export class GameCollection {
  enemies: ServerEnemy[];
  gamers: ServerUserGamer[];
  complexity: EServerRoomComplexity;
  stage: number;
  status: EGameCollectionStatus;
  attackEnemyTimer: any;
  generateTimer: any;
  moveTimer: any;
  healthTimer: any;
  energyTimer: any;
  field: IField;
  constructor(complexity: EServerRoomComplexity, field: IField, users: ServerUser[]) {
    this.enemies = [];
    this.gamers = users.map((user) => {
      return new ServerUserGamer(200, 5, user.username);
    });
    this.complexity = EServerRoomComplexity.Easy;
    this.stage = 1;
    this.status = EGameCollectionStatus.WAITING;
    this.field = field;
  }
  generateEnemies = () => {
    const enemyType = getRandomInt(3) as 0 | 1 | 2;
    const enemiesType = {0: Enemies.Light, 1: Enemies.Medium, 2: Enemies.Large};
    const newEnemy = enemiesType[enemyType].clone();
    const x = getRandomInt(this.field.xEnd - this.field.xStart) + this.field.xStart;
    const y = getRandomInt(this.field.yEnd - this.field.yStart) + this.field.yStart;
    newEnemy.setPosition({x, y});
    this.enemies.push(newEnemy);
  };
  moveEnemies = () => {
    for (let enemy of this.enemies) {
      enemy.autoMove(this.field);
    }
  };
  healthGamers = () => {
    for (let gamer of this.gamers) {
      gamer.updateHealth();
    }
  };
  updateGamerEnergy = () => {
    for (let gamer of this.gamers) {
      gamer.updateEnergy();
    }
  };
  attackEnemies = () => {
    const procent = getRandomInt(100);
    for (let enemy of this.enemies) {
      if (procent < 50) {
        const gamer = this.gamers[getRandomInt(this.gamers.length)];
        setTimeout(() => {
          gamer.getDamage(enemy.power);
        }, 500);
      }
    }
  };
  shotByGamer = (position: IPoint, username: string) => {
    const gamer = this.gamers.find((currentGamer) => currentGamer.username === username);
    if (gamer && gamer.health > 0 && gamer.energy >= 10) {
      gamer.shot();
      for (let enemy of this.enemies) {
        const successHit = enemy.shot(position, gamer.getPower());
        if (successHit) {
          break;
        }
      }
    }
  };
  start() {
    this.generateTimer = setInterval(() => {
      this.generateEnemies();
    }, 2000);
    this.moveTimer = setInterval(() => {
      this.moveEnemies();
    }, 1000);
    this.healthTimer = setInterval(() => {
      this.healthGamers();
    }, 5000);
    this.energyTimer = setInterval(() => {
      this.updateGamerEnergy();
    }, 250);
    this.attackEnemyTimer = setInterval(() => {
      this.attackEnemies();
    }, 1500);
    this.status = EGameCollectionStatus.STAGE;
    setTimeout(() => {
      clearInterval(this.energyTimer);
      clearInterval(this.healthTimer);
      clearInterval(this.generateTimer);
      clearInterval(this.moveTimer);
      clearInterval(this.attackEnemyTimer);
      this.status = EGameCollectionStatus.WAITING;
    }, 60000);
  }
}
