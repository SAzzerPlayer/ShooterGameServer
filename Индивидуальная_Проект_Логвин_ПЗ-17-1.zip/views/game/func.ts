const CURRENT_ROOM_USER = {
  roomId: '',
  username: '',
  key: '',
  avatar: 0,
};

const gamerSocket = new WebSocket('ws://localhost:8080/');

gamerSocket.onmessage = (messageEvent) => {
  const message = JSON.parse(messageEvent.data);
  console.log(message);
  switch (message.type) {
    case 'MAIN/BIND_USER': {
      const message = {
        type: 'GAME/START_STAGE',
        data: {
          user: {
            username: CURRENT_ROOM_USER.username,
          },
        },
      };
      gamerSocket.send(JSON.stringify(message));
      break;
    }
    case 'GAME/GENERATE_ENEMY': {
      shotEffect({x: 200, y: 200} as any);
      break;
    }
  }
};

gamerSocket.onopen = (messageEvent: Event) => {
  console.log('Socket is opening. Start binding the user');
  const message = {
    type: 'MAIN/BIND_USER',
    data: {
      user: CURRENT_ROOM_USER,
    },
  };
  gamerSocket.send(JSON.stringify(message));
};

gamerSocket.onerror = (err) => {
  console.log(`Socket error!!! ${err}`);
};

gamerSocket.onclose = (messageEvent: Event) => {
  setTimeout(() => {
    window.location.href = `/`;
  }, 20000);
  alert('Socket has closed. Something was happened');
};

const leaveRoom = () => {
  window.location.href = '/lobbies';
};

const checkRoomUserHasData = () => {
  const key = sessionStorage.getItem('key');
  const username = sessionStorage.getItem('username');
  const avatar = sessionStorage.getItem('avatar');
  const roomId = sessionStorage.getItem('roomId');
  CURRENT_ROOM_USER.key = key as string;
  CURRENT_ROOM_USER.username = username as string;
  CURRENT_ROOM_USER.avatar = Number(avatar) as number;
  CURRENT_ROOM_USER.roomId = roomId as string;
  if (!key || !username || !avatar || !roomId) {
    window.location.href = `/`;
  }
};
checkRoomUserHasData();
