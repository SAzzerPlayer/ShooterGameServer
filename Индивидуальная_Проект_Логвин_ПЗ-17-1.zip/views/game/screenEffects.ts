const shotEffect = (event: MouseEvent) => {
  const ShotDiv = document.createElement('div') as HTMLDivElement;
  let size = 32;
  ShotDiv.style.width = `${size}px`;
  ShotDiv.style.height = `${size}px`;
  ShotDiv.style.position = 'absolute';
  ShotDiv.style.left = `${event.x}px`;
  ShotDiv.style.top = `${event.y}px`;
  ShotDiv.style.backgroundColor = 'red';
  ShotDiv.style.borderRadius = `${size / 2}px`;
  document.getElementById('game-area')?.appendChild(ShotDiv);
  let timer = setInterval(() => {
    if (size > 0) size -= 4;
    ShotDiv.style.width = `${size}px`;
    ShotDiv.style.height = `${size}px`;
    ShotDiv.style.borderRadius = `${size / 2}px`;
  }, 50);
  setTimeout(() => {
    clearInterval(timer);
    document.getElementById('game-area')?.removeChild(ShotDiv);
  }, 900);
  gamerShotEffect(1);
};

const gamerShotEffect = (userNumber: number) => {
  const userAvatar = document.getElementById(`gamer-${userNumber}-avatar`) as HTMLDivElement;
  userAvatar.style.border = '2px red solid';
  setTimeout(() => {
    userAvatar.style.border = '0';
  }, 100);
};
